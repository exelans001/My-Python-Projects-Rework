#Rastgele atılan 2 zarın toplamı

import random

zar1=random.randint(1, 6)
zar2=random.randint(1, 6)
ztoplam= zar1 + zar2

print(f"1.Zar: {zar1}")
print(f"2.Zar: {zar2}")
print(f"Zar Toplamı: {ztoplam}")